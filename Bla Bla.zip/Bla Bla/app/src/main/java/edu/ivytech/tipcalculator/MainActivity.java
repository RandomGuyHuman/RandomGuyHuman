package edu.ivytech.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

  private EditText billAmountEditText;
  private TextView percentTextView;
  private TextView tipTextView;
  private TextView totalTextView;
  private float tipPercent = .15f;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main_layout);

    billAmountEditText = findViewById(R.id.billAmountEditText);
    percentTextView = findViewById(R.id.percentTextView);
    tipTextView = findViewById(R.id.tipTextView);
    totalTextView = findViewById(R.id.totalTextView);

    TextView splitBillEditText = findViewById(R.id.splitBillEditText); //get split bill amount object
    String SplitBillAmt = splitBillEditText.getText().toString(); // turn into string Created SplitBillAmt
    if (SplitBillAmt.contentEquals("")){

    } else {
      long SplitBill = Long.parseLong(SplitBillAmt);// turn string into number
      EditText splitWaysEditText = findViewById(R.id.splitWaysEditText); // grab split ways object
      String stringSplitWays = splitWaysEditText.getText().toString(); // turn into string
      long numSplitWays = Long.parseLong(stringSplitWays); // turn string into number

      TextView eachPaysTextView = findViewById(R.id.eachPaysTextView);//grab each pays object
      String eaPaysString = eachPaysTextView.getText().toString(); //turn object into string
      long eaNum = Long.parseLong(eaPaysString);// turn string into number??
      Log.i("info",eaNum+"");

      //eachPaysTextView.setText((SplitBill / numSplitWays + ""));// Long SplitBill + Long SplitWays =  Each pays???
    }
  }

  public void calculateAndDisplay() {
    String billAmountString = billAmountEditText.getText().toString();
    float billAmount;
    if(billAmountString.equals("")) {
      billAmount = 0;
    }
    else {
      billAmount = Float.parseFloat(billAmountString);
    }
    float tipAmount = billAmount * tipPercent;
    float totalAmount = billAmount + tipAmount;

    NumberFormat currency = NumberFormat.getCurrencyInstance();
    tipTextView.setText(currency.format(tipAmount));
    totalTextView.setText(currency.format(totalAmount));

    NumberFormat percent = NumberFormat.getPercentInstance();
    percentTextView.setText(percent.format(tipPercent));

  }

  @Override
  public void onResume() {
    super.onResume();
    calculateAndDisplay();
  }

  public void onCalculateClick(View v) {

    calculateAndDisplay();
  }

  public void onSplitCalculateClick(View v) {
    TextView splitBillEditText = findViewById(R.id.splitBillEditText); //get split bill amount object
    String SplitBillAmt = splitBillEditText.getText().toString(); // turn into string Created SplitBillAmt
    long SplitBill = Long.parseLong(SplitBillAmt);// turn string into number

    EditText splitWaysEditText = findViewById(R.id.splitWaysEditText); // grab split ways object
    String stringSplitWays = splitWaysEditText.getText().toString(); // turn into string
    long numSplitWays = Long.parseLong(stringSplitWays); // turn string into number

    TextView eachPaysTextView = findViewById(R.id.eachPaysTextView);//grab each pays object
    String eaPaysString = eachPaysTextView.getText().toString(); //turn object into string
    long eaNum = Long.parseLong(eaPaysString);// turn string into number??

    eachPaysTextView.setText((SplitBill / numSplitWays + ""));// Long SplitBill + Long SplitWays =  Each pays???
  }

  public void onPercentClick(View v) {
    switch (v.getId()) {
      case R.id.percentDownButton:
        tipPercent = tipPercent - .01f;
        break;
      case R.id.percentUpButton:
        tipPercent = tipPercent + .01f;
        break;
    }

    calculateAndDisplay();
  }
}
